Include 
	<script src="//maps.googleapis.com/maps/api/js?key=AIzaSyCZfHRnq7tigC-COeQRmoa9Cxr0vbrK6xw&sensor=false" type="text/javascript"></script>
        