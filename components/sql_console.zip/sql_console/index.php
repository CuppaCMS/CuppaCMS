<?php
    require_once "../../classes/Cuppa.php"; 
    $cuppa = Cuppa::getInstance(); $cuppa->user->valid();
    if(!$cuppa->user->getVar("admin_login")) exit();
    if(@$cuppa->POST("task") == "execute"){
        $sql = base64_decode($cuppa->POST("sql"));
        $result = $cuppa->dataBase->sql($sql);
        $error = $cuppa->dataBase->getError();
    }
?>
<style>
    .sql_script{ }
    .sql_script textarea{ width: 100%; height: 250px; }
    .sql_script blockquote{ margin: 9px 0px; }
    .sql_script .btn_execute{ position: relative; float: right; margin: 5px 0px; }
    .sql_script .message{ position: relative; overflow: hidden; padding: 10px 20px; background: #FFEDED; margin: 5px 0px; }
    .sql_script .message2{ position: relative; overflow: hidden; padding: 10px 20px; background: #F2FFED; margin: 5px 0px; }
</style>
<script>
    sql_script = {}
    sql_script.update = function(){
        if(!$(".sql_script form").valid()) return;
        var data = cuppa.serialize(".sql_script form");
            data.sql = jQuery.base64Encode(data.sql);
        cuppa.managerURL.setParams({path:"component/sql_console"}, true, data);
    }
</script>
<div class="sql_script">
    <h1>SQL Console <span class="title_info">Use this console with responsability.</span></h1>
    <div style="padding: 5px 0px 5px;">
        Create tables directly in the <strong>Database</strong>, after config it with <strong>Table Manager</strong>. 
    </div>
    <?php if(@$error->code){ ?>
        <div class="message"><?php echo @$error->message ?></div>
    <?php }else if(@$cuppa->POST("task") == "execute"){ ?>
        <div class="message2">Your SQL was excecute correctly</div>
    <?php } ?>
    <form style="display: block; overflow: hidden;" method="post" onsubmit="return false">
        <textarea class="required" name="sql"></textarea>
        <input type="hidden" name="task" value="execute" />
        <button class="button_blue btn_execute" onclick="sql_script.update()" >Execute</button>
    </form>
    <blockquote>
        <?php $cuppa->echoString(@$cuppa->language->getValueRich("sql_scripts")) ?>
    </blockquote>
</div>